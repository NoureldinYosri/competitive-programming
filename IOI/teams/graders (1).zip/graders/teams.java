public class teams {

	public void init(int N, int A[], int B[]){

	}

	public int can(int M, int K[]){
		return 0;
	}
	
}