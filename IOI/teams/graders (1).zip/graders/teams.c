#include "teams.h"

void init(int N, int A[], int B[]) {
}

int can(int M, int K[]) {
	return 0;
}
