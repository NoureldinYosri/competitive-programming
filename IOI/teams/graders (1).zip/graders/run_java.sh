#!/bin/bash

problem=teams

java -jar -Xmx1500M -Xms1400M -Xss64M $problem.jar
