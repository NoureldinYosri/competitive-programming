void Anna( int N, long long X, int K, int P[] );
void Set( int pos, int bit );
