long long Bruno( int N, int A[] );
