#include "Brunolib.h"

long long Bruno( int N, int A[] ){
  return 0LL;
}
